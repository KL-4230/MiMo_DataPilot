"""MiMo 行业大数据智能研判决策中台 - 包初始化"""
__version__ = "1.0.0"
__project__ = "MiMo Industry Intelligence Platform"
