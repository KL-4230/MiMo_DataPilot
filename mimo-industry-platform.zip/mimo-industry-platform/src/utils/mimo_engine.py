"""MiMo 大模型推理引擎 - 支持本地/云端/混合三种模式"""

import asyncio
import json
import time
from typing import Any, AsyncIterator, Dict, List, Optional
from enum import Enum

import httpx
from openai import AsyncOpenAI
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential

from .config import get_setting
from .logger import setup_logging


class DeployMode(str, Enum):
    LOCAL = "local"
    CLOUD = "cloud"
    HYBRID = "hybrid"


class MiMoEngine:
    """MiMo-V2.5 大模型推理引擎

    支持三种部署模式:
    - cloud: 调用小米云端 API
    - local: 调用本地部署 (Ollama/vLLM)
    - hybrid: 智能路由，短任务本地、长任务云端
    """

    def __init__(self):
        setup_logging()
        self.mode = DeployMode(get_setting("model.mode", "cloud"))
        self._cloud_client: Optional[AsyncOpenAI] = None
        self._local_client: Optional[AsyncOpenAI] = None
        self._usage_stats = {"total_tokens": 0, "total_requests": 0, "total_cost": 0.0}

    @property
    def cloud_client(self) -> AsyncOpenAI:
        if self._cloud_client is None:
            api_key = get_setting("model.cloud.api_key", "")
            api_base = get_setting("model.cloud.api_base", "")
            self._cloud_client = AsyncOpenAI(
                api_key=api_key,
                base_url=api_base,
                timeout=get_setting("model.cloud.timeout", 120),
                max_retries=get_setting("model.cloud.max_retries", 3),
            )
        return self._cloud_client

    @property
    def local_client(self) -> AsyncOpenAI:
        if self._local_client is None:
            api_base = get_setting("model.local.api_base", "http://localhost:11434/v1")
            self._local_client = AsyncOpenAI(
                api_key="ollama",  # Ollama 不需要真实 key
                base_url=api_base,
                timeout=120,
            )
        return self._local_client

    def _select_mode(self, prompt_length: int) -> DeployMode:
        """根据输入长度智能选择部署模式"""
        if self.mode != DeployMode.HYBRID:
            return self.mode

        short_threshold = get_setting("model.hybrid.short_task_threshold", 8000)
        long_threshold = get_setting("model.hybrid.long_task_threshold", 100000)

        if prompt_length < short_threshold:
            return DeployMode.LOCAL
        elif prompt_length > long_threshold:
            return DeployMode.CLOUD
        return DeployMode.LOCAL

    def _get_client(self, mode: DeployMode) -> AsyncOpenAI:
        if mode == DeployMode.CLOUD:
            return self.cloud_client
        return self.local_client

    def _get_model_name(self, mode: DeployMode) -> str:
        if mode == DeployMode.CLOUD:
            return get_setting("model.cloud.model_name", "mimo-v2.5")
        return get_setting("model.local.model_name", "mimo-v2.5-local")

    # ----------------------------------------------------------------
    # 核心推理接口
    # ----------------------------------------------------------------

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=2, max=30))
    async def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        json_mode: bool = False,
        mode_override: Optional[DeployMode] = None,
    ) -> Dict[str, Any]:
        """单次对话推理"""
        prompt_len = sum(len(m.get("content", "")) for m in messages)
        mode = mode_override or self._select_mode(prompt_len)
        client = self._get_client(mode)
        model = self._get_model_name(mode)

        kwargs: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature or get_setting("model.cloud.temperature", 0.3),
            "max_tokens": max_tokens or get_setting("model.cloud.max_output_tokens", 32768),
        }
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}

        start = time.time()
        try:
            response = await client.chat.completions.create(**kwargs)
            elapsed = time.time() - start

            result = {
                "content": response.choices[0].message.content or "",
                "model": response.model,
                "mode": mode.value,
                "usage": {
                    "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
                    "completion_tokens": response.usage.completion_tokens if response.usage else 0,
                    "total_tokens": response.usage.total_tokens if response.usage else 0,
                },
                "elapsed_seconds": round(elapsed, 2),
            }

            self._usage_stats["total_tokens"] += result["usage"]["total_tokens"]
            self._usage_stats["total_requests"] += 1

            logger.info(
                f"MiMo 推理完成 | mode={mode.value} | "
                f"tokens={result['usage']['total_tokens']} | "
                f"time={elapsed:.1f}s"
            )
            return result

        except Exception as e:
            if mode == DeployMode.LOCAL and self.mode == DeployMode.HYBRID:
                logger.warning(f"本地推理失败，回退到云端: {e}")
                return await self.chat(
                    messages, temperature, max_tokens, json_mode,
                    mode_override=DeployMode.CLOUD,
                )
            raise

    async def chat_stream(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> AsyncIterator[str]:
        """流式对话推理"""
        prompt_len = sum(len(m.get("content", "")) for m in messages)
        mode = self._select_mode(prompt_len)
        client = self._get_client(mode)
        model = self._get_model_name(mode)

        kwargs = {
            "model": model,
            "messages": messages,
            "temperature": temperature or 0.3,
            "max_tokens": max_tokens or 32768,
            "stream": True,
        }

        stream = await client.chat.completions.create(**kwargs)
        async for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content

    # ----------------------------------------------------------------
    # 批量推理（用于海量数据解析）
    # ----------------------------------------------------------------

    async def batch_infer(
        self,
        batch_messages: List[List[Dict[str, str]]],
        max_concurrent: int = 5,
        **kwargs,
    ) -> List[Dict[str, Any]]:
        """批量并发推理，控制并发数避免过载"""
        semaphore = asyncio.Semaphore(max_concurrent)

        async def _run_one(msgs):
            async with semaphore:
                return await self.chat(msgs, **kwargs)

        tasks = [_run_one(msgs) for msgs in batch_messages]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        output = []
        for i, r in enumerate(results):
            if isinstance(r, Exception):
                logger.error(f"批量推理第 {i} 项失败: {r}")
                output.append({"error": str(r), "index": i})
            else:
                output.append(r)
        return output

    # ----------------------------------------------------------------
    # 超长上下文处理（百万级 token 分块拼接）
    # ----------------------------------------------------------------

    async def long_context_infer(
        self,
        system_prompt: str,
        long_content: str,
        chunk_size: int = 50000,
        overlap: int = 2000,
        summary_prompt: str = "请对以上内容进行精炼总结，提取关键信息点。",
    ) -> str:
        """超长上下文分块处理 -> 逐块总结 -> 汇总推理

        实现百万级上下文的阶梯式处理:
        1. 将长内容切割为 chunk_size 大小的块
        2. 每块独立推理提取关键信息
        3. 汇总所有块的关键信息做最终推理
        """
        if len(long_content) <= chunk_size:
            # 内容在单次推理范围内，直接处理
            result = await self.chat([
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": long_content},
            ])
            return result["content"]

        # Step 1: 分块
        chunks = self._split_chunks(long_content, chunk_size, overlap)
        logger.info(f"超长内容切割为 {len(chunks)} 个块 (每块 {chunk_size} 字符)")

        # Step 2: 逐块推理提取关键信息
        chunk_summaries = []
        batch_size = get_setting("parser.batch_size", 50)

        for batch_start in range(0, len(chunks), batch_size):
            batch = chunks[batch_start:batch_start + batch_size]
            batch_msgs = [
                [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"以下是数据块 {i+1}/{len(chunks)}:\n\n{chunk}\n\n{summary_prompt}"},
                ]
                for i, chunk in enumerate(batch, batch_start)
            ]
            results = await self.batch_infer(batch_msgs, max_concurrent=5)
            for r in results:
                if "content" in r:
                    chunk_summaries.append(r["content"])

        # Step 3: 汇总所有块的总结
        combined = "\n\n---\n\n".join(chunk_summaries)
        final_result = await self.chat([
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"以下是分块分析结果汇总，请进行综合研判:\n\n{combined}"},
        ])
        return final_result["content"]

    @staticmethod
    def _split_chunks(text: str, chunk_size: int, overlap: int) -> List[str]:
        """将文本切割为有重叠的块"""
        chunks = []
        start = 0
        while start < len(text):
            end = min(start + chunk_size, len(text))
            chunks.append(text[start:end])
            start = end - overlap if end < len(text) else end
        return chunks

    def get_usage_stats(self) -> Dict[str, Any]:
        """获取使用统计"""
        return dict(self._usage_stats)


# 全局单例
_engine: Optional[MiMoEngine] = None


def get_engine() -> MiMoEngine:
    global _engine
    if _engine is None:
        _engine = MiMoEngine()
    return _engine
