"""日志模块 - 基于 loguru 的统一日志管理"""

import sys
from pathlib import Path
from loguru import logger
from .config import get_setting


def setup_logging():
    """初始化日志系统"""
    logger.remove()  # 移除默认 handler

    level = get_setting("logging.level", "INFO")
    fmt = get_setting("logging.format",
        "{time:YYYY-MM-DD HH:mm:ss} | {level} | {module} | {message}")
    rotation = get_setting("logging.rotation", "100 MB")
    retention = get_setting("logging.retention", "30 days")

    # 控制台输出
    logger.add(
        sys.stderr,
        level=level,
        format=fmt,
        colorize=True,
    )

    # 文件输出
    log_dir = Path(get_setting("storage.log_dir", "./logs"))
    log_dir.mkdir(parents=True, exist_ok=True)
    logger.add(
        str(log_dir / "platform_{time:YYYY-MM-DD}.log"),
        level=level,
        format=fmt,
        rotation=rotation,
        retention=retention,
        encoding="utf-8",
    )

    logger.info("日志系统初始化完成")
    return logger
