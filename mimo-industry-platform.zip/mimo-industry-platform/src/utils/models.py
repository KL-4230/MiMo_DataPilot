"""数据模型定义 - Pydantic v2 models for the entire platform"""

from __future__ import annotations
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


# ============================================================
# 枚举类型
# ============================================================

class DataSource(str, Enum):
    INDUSTRY = "industry"
    MARKET = "market"
    USER_BEHAVIOR = "user_behavior"
    POLICY = "policy"
    SOCIAL = "social"


class DataType(str, Enum):
    TEXT = "text"
    TABLE = "table"
    JSON = "json"
    HTML = "html"
    CSV = "csv"
    API = "api"


class AnalysisDepth(str, Enum):
    QUICK = "quick"
    STANDARD = "standard"
    COMPREHENSIVE = "comprehensive"


class RiskLevel(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    NONE = "none"


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


# ============================================================
# 采集层数据模型
# ============================================================

class RawDataItem(BaseModel):
    """原始数据条目"""
    id: Optional[str] = None
    source: DataSource
    data_type: DataType
    url: Optional[str] = None
    title: str = ""
    content: str
    metadata: Dict[str, Any] = Field(default_factory=dict)
    collected_at: datetime = Field(default_factory=datetime.now)
    tags: List[str] = Field(default_factory=list)


class CleanedDataItem(BaseModel):
    """清洗后数据条目"""
    id: Optional[str] = None
    source: DataSource
    title: str
    content: str
    summary: str = ""
    category: str = ""
    subcategory: str = ""
    dimensions: Dict[str, str] = Field(default_factory=dict)
    quality_score: float = 0.0
    is_duplicate: bool = False
    original_id: Optional[str] = None
    cleaned_at: datetime = Field(default_factory=datetime.now)


class CollectionConfig(BaseModel):
    """数据采集配置"""
    sources: List[DataSource]
    keywords: List[str] = Field(default_factory=list)
    date_range: Optional[tuple[str, str]] = None
    max_items: int = 1000
    categories: List[str] = Field(default_factory=list)


# ============================================================
# 解析层数据模型
# ============================================================

class ParseResult(BaseModel):
    """解析结果"""
    batch_id: str
    total_items: int
    parsed_items: int
    failed_items: int
    dimensions_extracted: Dict[str, List[str]] = Field(default_factory=dict)
    key_findings: List[str] = Field(default_factory=list)
    data_quality: float = 0.0
    execution_time_seconds: float = 0.0


class DataChunk(BaseModel):
    """数据分块"""
    chunk_id: str
    batch_id: str
    content: str
    index: int
    total_chunks: int
    overlap_start: int = 0
    overlap_end: int = 0


class AggregatedData(BaseModel):
    """聚合后的数据"""
    aggregation_id: str
    industry: str
    time_range: str
    dimensions: Dict[str, Any] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(default_factory=dict)
    summary: str = ""
    source_count: int = 0
    created_at: datetime = Field(default_factory=datetime.now)


# ============================================================
# 研判层数据模型
# ============================================================

class TrendAnalysis(BaseModel):
    """趋势分析结果"""
    industry: str
    trend_direction: str  # rising / stable / declining
    confidence: float
    key_drivers: List[str] = Field(default_factory=list)
    timeline: str = ""
    data_points: List[Dict[str, Any]] = Field(default_factory=list)
    summary: str = ""


class RiskWarning(BaseModel):
    """风险预警"""
    risk_id: str
    industry: str
    risk_type: str
    level: RiskLevel
    description: str
    indicators: List[str] = Field(default_factory=list)
    impact_assessment: str = ""
    recommended_actions: List[str] = Field(default_factory=list)
    confidence: float = 0.0
    detected_at: datetime = Field(default_factory=datetime.now)


class SupplyDemandAnalysis(BaseModel):
    """供需关系分析"""
    industry: str
    supply_score: float  # 0-1
    demand_score: float  # 0-1
    balance_status: str  # surplus / balanced / shortage
    key_factors: List[str] = Field(default_factory=list)
    forecast: str = ""
    data_sources: List[str] = Field(default_factory=list)


class MarketOpportunity(BaseModel):
    """市场机会"""
    opportunity_id: str
    industry: str
    title: str
    description: str
    potential_score: float  # 0-1
    time_window: str
    required_capabilities: List[str] = Field(default_factory=list)
    competitive_intensity: str = ""
    entry_barriers: List[str] = Field(default_factory=list)


class InferenceReport(BaseModel):
    """完整研判报告"""
    report_id: str
    industry: str
    task_name: str
    trends: List[TrendAnalysis] = Field(default_factory=list)
    risks: List[RiskWarning] = Field(default_factory=list)
    supply_demand: Optional[SupplyDemandAnalysis] = None
    opportunities: List[MarketOpportunity] = Field(default_factory=list)
    executive_summary: str = ""
    confidence_score: float = 0.0
    generated_at: datetime = Field(default_factory=datetime.now)


# ============================================================
# 可视化层数据模型
# ============================================================

class ChartSpec(BaseModel):
    """图表规格"""
    chart_id: str
    chart_type: str  # line / bar / pie / scatter / heatmap / radar
    title: str
    data: List[Dict[str, Any]] = Field(default_factory=list)
    x_axis: str = ""
    y_axis: str = ""
    series: List[str] = Field(default_factory=list)
    options: Dict[str, Any] = Field(default_factory=dict)


class ReportSpec(BaseModel):
    """报表规格"""
    report_id: str
    title: str
    industry: str
    sections: List[Dict[str, Any]] = Field(default_factory=list)
    charts: List[ChartSpec] = Field(default_factory=list)
    format: str = "html"
    generated_at: datetime = Field(default_factory=datetime.now)


# ============================================================
# 推荐层数据模型
# ============================================================

class Recommendation(BaseModel):
    """决策推荐"""
    rec_id: str
    category: str  # business_strategy / ecommerce / investment / risk_mitigation
    title: str
    description: str
    rationale: str
    action_items: List[str] = Field(default_factory=list)
    priority: int = 5  # 1-10
    confidence: float = 0.0
    related_industry: str = ""
    time_horizon: str = ""  # short / medium / long
    expected_impact: str = ""
    risks: List[str] = Field(default_factory=list)


# ============================================================
# Agent 任务模型
# ============================================================

class AgentTask(BaseModel):
    """Agent 任务"""
    task_id: str
    task_type: str
    industry: str
    parameters: Dict[str, Any] = Field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


class AgentPipeline(BaseModel):
    """Agent 工作流管道"""
    pipeline_id: str
    name: str
    industry: str
    tasks: List[AgentTask] = Field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
    created_at: datetime = Field(default_factory=datetime.now)
