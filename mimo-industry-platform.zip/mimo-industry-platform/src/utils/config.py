"""配置管理模块 - 统一加载 settings.yaml + 环境变量"""

import os
import yaml
from pathlib import Path
from typing import Any, Dict, Optional
from functools import lru_cache
from loguru import logger


CONFIG_DIR = Path(__file__).parent.parent.parent / "config"
_settings_cache: Optional[Dict] = None


def _resolve_env_vars(value: Any) -> Any:
    """递归解析 ${ENV_VAR} 占位符"""
    if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
        env_key = value[2:-1]
        resolved = os.environ.get(env_key, "")
        if not resolved:
            logger.warning(f"环境变量 {env_key} 未设置")
        return resolved
    if isinstance(value, dict):
        return {k: _resolve_env_vars(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve_env_vars(v) for v in value]
    return value


@lru_cache(maxsize=1)
def load_settings(config_path: Optional[str] = None) -> Dict:
    """加载配置文件，支持环境变量替换"""
    global _settings_cache
    if _settings_cache is not None:
        return _settings_cache

    path = Path(config_path) if config_path else CONFIG_DIR / "settings.yaml"
    if not path.exists():
        logger.warning(f"配置文件不存在: {path}，使用默认配置")
        _settings_cache = _default_settings()
        return _settings_cache

    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)

    _settings_cache = _resolve_env_vars(raw)
    logger.info(f"配置已加载: {path}")
    return _settings_cache


def get_setting(dot_path: str, default: Any = None) -> Any:
    """通过点号路径获取配置项，如 'model.cloud.api_key'"""
    settings = load_settings()
    keys = dot_path.split(".")
    current = settings
    for key in keys:
        if isinstance(current, dict):
            current = current.get(key)
        else:
            return default
        if current is None:
            return default
    return current


def _default_settings() -> Dict:
    """默认配置（无文件时的兜底）"""
    return {
        "model": {
            "mode": "cloud",
            "cloud": {
                "api_base": "https://api.xiaomi.com/mimo/v1",
                "api_key": os.environ.get("MIMO_API_KEY", ""),
                "model_name": "mimo-v2.5",
                "max_context_length": 1000000,
                "max_output_tokens": 32768,
                "temperature": 0.3,
                "timeout": 120,
            },
        },
        "storage": {
            "database_url": "sqlite+aiosqlite:///data/industry_platform.db",
            "data_dir": "./data",
        },
        "api": {"host": "0.0.0.0", "port": 8000},
        "logging": {"level": "INFO"},
    }
