"""多源异构数据自动化采集模块

支持: 行业公开数据、市场经营数据、用户行为数据
能力: 批量抓取、格式统一清洗、冗余数据过滤、自动分类归档
"""

import asyncio
import hashlib
import json
import re
import uuid
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin, urlparse

import aiohttp
from bs4 import BeautifulSoup
from loguru import logger

from ..utils.config import get_setting
from ..utils.models import (
    RawDataItem, CleanedDataItem, CollectionConfig,
    DataSource, DataType,
)


# ============================================================
# 采集器基类
# ============================================================

class BaseCollector(ABC):
    """数据采集器基类"""

    def __init__(self, source: DataSource):
        self.source = source
        self.user_agents = get_setting("collectors.user_agents", [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0"
        ])
        self.delay = get_setting("collectors.request_delay_ms", 500) / 1000
        self.max_concurrent = get_setting("collectors.max_concurrent_requests", 20)
        self.retry_attempts = get_setting("collectors.retry_attempts", 3)
        self._session: Optional[aiohttp.ClientSession] = None
        self._seen_hashes: set = set()

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=30)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()

    async def _fetch_url(self, url: str, headers: Optional[Dict] = None) -> str:
        """带重试的 HTTP GET"""
        session = await self._get_session()
        hdrs = headers or {"User-Agent": self.user_agents[0]}

        for attempt in range(self.retry_attempts):
            try:
                await asyncio.sleep(self.delay)
                async with session.get(url, headers=hdrs) as resp:
                    if resp.status == 200:
                        return await resp.text()
                    elif resp.status == 429:
                        wait = 2 ** attempt * 2
                        logger.warning(f"限流 {url}，等待 {wait}s")
                        await asyncio.sleep(wait)
                    else:
                        logger.warning(f"HTTP {resp.status}: {url}")
            except Exception as e:
                logger.warning(f"请求失败 (attempt {attempt+1}): {url} - {e}")
                await asyncio.sleep(1)

        raise Exception(f"采集失败: {url}")

    def _content_hash(self, content: str) -> str:
        return hashlib.md5(content.encode()).hexdigest()

    def _is_duplicate(self, content: str) -> bool:
        h = self._content_hash(content)
        if h in self._seen_hashes:
            return True
        self._seen_hashes.add(h)
        return False

    @abstractmethod
    async def collect(self, config: CollectionConfig) -> List[RawDataItem]:
        """执行数据采集"""
        ...


# ============================================================
# 行业公开数据采集器
# ============================================================

class IndustryDataCollector(BaseCollector):
    """行业公开数据采集器

    采集来源: 行业报告网站、新闻资讯、政策公告等公开渠道
    """

    def __init__(self):
        super().__init__(DataSource.INDUSTRY)
        # 预定义的公开数据源 (示例 URL，实际使用时替换为真实数据源)
        self.data_sources = {
            "market_reports": [
                "https://example.com/industry-reports",
            ],
            "industry_news": [
                "https://example.com/industry-news",
            ],
            "policy_updates": [
                "https://example.com/policy",
            ],
        }

    async def collect(self, config: CollectionConfig) -> List[RawDataItem]:
        logger.info(f"开始采集行业公开数据 | 关键词: {config.keywords}")
        items: List[RawDataItem] = []
        semaphore = asyncio.Semaphore(self.max_concurrent)

        async def _collect_one(url: str, category: str):
            async with semaphore:
                try:
                    html = await self._fetch_url(url)
                    parsed = self._parse_page(html, url, category)
                    items.extend(parsed)
                except Exception as e:
                    logger.error(f"采集失败: {url} - {e}")

        tasks = []
        for category in (config.categories or self.data_sources.keys()):
            for url in self.data_sources.get(category, []):
                tasks.append(_collect_one(url, category))

        await asyncio.gather(*tasks)
        logger.info(f"行业数据采集完成: {len(items)} 条")
        return items[:config.max_items]

    def _parse_page(self, html: str, url: str, category: str) -> List[RawDataItem]:
        """通用网页解析器"""
        soup = BeautifulSoup(html, "lxml")
        items = []

        # 尝试提取文章列表
        articles = soup.find_all(["article", "div"], class_=re.compile(r"(article|post|news|item)", re.I))
        for article in articles[:50]:
            title_el = article.find(["h1", "h2", "h3", "h4", "a"])
            if not title_el:
                continue
            title = title_el.get_text(strip=True)
            content = article.get_text(strip=True)

            if len(content) < 50 or self._is_duplicate(content):
                continue

            items.append(RawDataItem(
                id=str(uuid.uuid4()),
                source=self.source,
                data_type=DataType.HTML,
                url=url,
                title=title,
                content=content,
                metadata={"category": category, "source_url": url},
                tags=[category],
            ))

        # 如果没有找到文章结构，提取页面整体内容
        if not items:
            main = soup.find("main") or soup.find("body")
            if main:
                content = main.get_text(separator="\n", strip=True)
                if len(content) >= 100 and not self._is_duplicate(content):
                    title = soup.title.string if soup.title else url
                    items.append(RawDataItem(
                        id=str(uuid.uuid4()),
                        source=self.source,
                        data_type=DataType.HTML,
                        url=url,
                        title=title,
                        content=content[:50000],
                        metadata={"category": category},
                    ))

        return items


# ============================================================
# 市场经营数据采集器
# ============================================================

class MarketDataCollector(BaseCollector):
    """市场经营数据采集器

    采集来源: 电商平台、品牌数据、价格监控等
    """

    def __init__(self):
        super().__init__(DataSource.MARKET)

    async def collect(self, config: CollectionConfig) -> List[RawDataItem]:
        logger.info(f"开始采集市场经营数据 | 关键词: {config.keywords}")
        items: List[RawDataItem] = []

        for keyword in config.keywords:
            # 模拟市场数据采集 (实际对接数据 API)
            market_data = self._generate_market_sample(keyword, config)
            items.extend(market_data)

        logger.info(f"市场数据采集完成: {len(items)} 条")
        return items[:config.max_items]

    def _generate_market_sample(self, keyword: str, config: CollectionConfig) -> List[RawDataItem]:
        """生成市场数据样本 (实际项目对接真实 API)"""
        import random

        items = []
        categories = config.categories or ["ecommerce_rankings", "brand_performance", "pricing_data"]

        for cat in categories:
            data = {
                "keyword": keyword,
                "category": cat,
                "timestamp": datetime.now().isoformat(),
                "metrics": {
                    "search_volume": random.randint(10000, 500000),
                    "avg_price": round(random.uniform(10, 5000), 2),
                    "market_share_top5": round(random.uniform(0.3, 0.8), 2),
                    "yoy_growth": round(random.uniform(-0.2, 0.5), 2),
                    "monthly_sales": random.randint(1000, 100000),
                    "competition_index": round(random.uniform(0.1, 1.0), 2),
                },
            }

            items.append(RawDataItem(
                id=str(uuid.uuid4()),
                source=self.source,
                data_type=DataType.JSON,
                title=f"{keyword} - {cat}",
                content=json.dumps(data, ensure_ascii=False),
                metadata=data,
                tags=[keyword, cat],
            ))

        return items


# ============================================================
# 用户行为数据采集器
# ============================================================

class UserBehaviorCollector(BaseCollector):
    """用户行为数据采集器

    采集来源: 搜索趋势、社交媒体、用户评价等
    """

    def __init__(self):
        super().__init__(DataSource.USER_BEHAVIOR)

    async def collect(self, config: CollectionConfig) -> List[RawDataItem]:
        logger.info(f"开始采集用户行为数据 | 关键词: {config.keywords}")
        items: List[RawDataItem] = []

        for keyword in config.keywords:
            behavior_data = self._generate_behavior_sample(keyword, config)
            items.extend(behavior_data)

        logger.info(f"用户行为数据采集完成: {len(items)} 条")
        return items[:config.max_items]

    def _generate_behavior_sample(self, keyword: str, config: CollectionConfig) -> List[RawDataItem]:
        """生成用户行为数据样本"""
        import random

        items = []
        time_periods = ["2024-Q1", "2024-Q2", "2024-Q3", "2024-Q4", "2025-Q1"]

        for period in time_periods:
            data = {
                "keyword": keyword,
                "time_period": period,
                "search_trends": {
                    "volume": random.randint(5000, 200000),
                    "growth_rate": round(random.uniform(-0.3, 0.8), 2),
                    "related_queries": [
                        f"{keyword}推荐", f"{keyword}排行", f"{keyword}评测",
                        f"{keyword}价格", f"{keyword}品牌",
                    ],
                },
                "social_mentions": {
                    "total_posts": random.randint(100, 50000),
                    "sentiment_positive": round(random.uniform(0.3, 0.7), 2),
                    "sentiment_negative": round(random.uniform(0.05, 0.25), 2),
                    "top_platforms": ["微博", "小红书", "抖音", "知乎"],
                },
                "review_sentiment": {
                    "avg_rating": round(random.uniform(3.0, 5.0), 1),
                    "review_count": random.randint(100, 10000),
                    "common_keywords": ["质量好", "性价比高", "物流快", "服务好"],
                },
            }

            items.append(RawDataItem(
                id=str(uuid.uuid4()),
                source=self.source,
                data_type=DataType.JSON,
                title=f"{keyword} 用户行为 - {period}",
                content=json.dumps(data, ensure_ascii=False),
                metadata=data,
                tags=[keyword, period, "user_behavior"],
            ))

        return items


# ============================================================
# 数据清洗器
# ============================================================

class DataCleaner:
    """数据清洗统一处理

    功能: 格式统一、去重、过滤、质量评分、自动分类
    """

    def __init__(self):
        self.min_length = get_setting("parser.cleaning.min_content_length", 50)
        self.max_length = get_setting("parser.cleaning.max_content_length", 500000)
        self._content_hashes: set = set()

    def clean_batch(self, raw_items: List[RawDataItem]) -> List[CleanedDataItem]:
        """批量清洗原始数据"""
        cleaned = []
        seen_titles = set()

        for item in raw_items:
            # 1. 内容清洗
            content = self._clean_text(item.content)
            if not content:
                continue

            # 2. 长度过滤
            if len(content) < self.min_length or len(content) > self.max_length:
                continue

            # 3. 去重检查
            content_hash = hashlib.md5(content.encode()).hexdigest()
            title_key = item.title[:50].lower().strip()
            if content_hash in self._content_hashes or title_key in seen_titles:
                cleaned_item = CleanedDataItem(
                    id=item.id,
                    source=item.source,
                    title=item.title,
                    content=content,
                    is_duplicate=True,
                    original_id=item.id,
                )
                continue
            self._content_hashes.add(content_hash)
            seen_titles.add(title_key)

            # 4. 自动分类
            category, subcategory = self._auto_classify(item)

            # 5. 维度提取
            dimensions = self._extract_dimensions(item)

            # 6. 质量评分
            quality = self._score_quality(content, item)

            cleaned.append(CleanedDataItem(
                id=item.id,
                source=item.source,
                title=item.title,
                content=content,
                summary=content[:200] + "..." if len(content) > 200 else content,
                category=category,
                subcategory=subcategory,
                dimensions=dimensions,
                quality_score=quality,
                original_id=item.id,
            ))

        logger.info(f"数据清洗完成: {len(raw_items)} -> {len(cleaned)} (去重率: {(1 - len(cleaned)/max(len(raw_items),1))*100:.1f}%)")
        return cleaned

    @staticmethod
    def _clean_text(text: str) -> str:
        """文本清洗"""
        if not text:
            return ""
        # 移除 HTML 标签
        text = re.sub(r"<[^>]+>", " ", text)
        # 规范化空白
        text = re.sub(r"\s+", " ", text)
        # 移除特殊控制字符
        text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)
        return text.strip()

    @staticmethod
    def _auto_classify(item: RawDataItem) -> tuple[str, str]:
        """基于关键词的自动分类"""
        content_lower = (item.title + " " + item.content[:500]).lower()

        categories = {
            "电商": ["电商", "ecommerce", "淘宝", "京东", "拼多多", "直播带货"],
            "科技": ["科技", "AI", "人工智能", "芯片", "半导体", "SaaS"],
            "消费": ["消费", "品牌", "零售", "餐饮", "食品", "美妆"],
            "金融": ["金融", "银行", "保险", "投资", "基金", "证券"],
            "医疗": ["医疗", "医药", "健康", "biotech", "制药"],
            "教育": ["教育", "培训", "在线学习", "K12"],
            "制造": ["制造", "工业", "供应链", "工厂", "智能制造"],
            "地产": ["地产", "房地产", "物业", "建筑"],
            "能源": ["能源", "新能源", "光伏", "储能", "碳中和"],
        }

        for cat, keywords in categories.items():
            if any(kw in content_lower for kw in keywords):
                return cat, "综合"

        return "其他", "未分类"

    @staticmethod
    def _extract_dimensions(item: RawDataItem) -> Dict[str, str]:
        """提取数据维度"""
        dims = {}

        # 时间维度
        date_match = re.search(r"20[2-3]\d", item.content[:500])
        if date_match:
            dims["time_period"] = date_match.group()

        # 来源维度
        dims["data_source"] = item.source.value
        dims["data_type"] = item.data_type.value

        # 地域维度
        regions = ["全国", "华东", "华南", "华北", "一线城市", "二线城市", "海外"]
        for r in regions:
            if r in item.content[:1000]:
                dims["region"] = r
                break

        return dims

    @staticmethod
    def _score_quality(content: str, item: RawDataItem) -> float:
        """数据质量评分 (0-1)"""
        score = 0.5  # 基础分

        # 长度加分
        if len(content) > 500:
            score += 0.1
        if len(content) > 2000:
            score += 0.1

        # 结构化程度加分
        if item.data_type in (DataType.JSON, DataType.TABLE, DataType.CSV):
            score += 0.15

        # 有标题加分
        if item.title and len(item.title) > 5:
            score += 0.05

        # 有 URL 来源加分
        if item.url:
            score += 0.05

        # 有标签加分
        if item.tags:
            score += 0.05

        return min(round(score, 2), 1.0)


# ============================================================
# 统一采集调度器
# ============================================================

class CollectionOrchestrator:
    """数据采集调度器

    统一调度各类采集器，完成多源数据的自动化采集和清洗
    """

    def __init__(self):
        self.collectors = {
            DataSource.INDUSTRY: IndustryDataCollector(),
            DataSource.MARKET: MarketDataCollector(),
            DataSource.USER_BEHAVIOR: UserBehaviorCollector(),
        }
        self.cleaner = DataCleaner()

    async def run_collection(
        self,
        config: CollectionConfig,
        auto_clean: bool = True,
    ) -> tuple[List[RawDataItem], List[CleanedDataItem]]:
        """执行完整的采集 + 清洗流程"""
        logger.info(f"启动数据采集流程 | 数据源: {[s.value for s in config.sources]}")

        all_raw: List[RawDataItem] = []

        # 并行采集各数据源
        tasks = []
        for source in config.sources:
            collector = self.collectors.get(source)
            if collector:
                tasks.append(collector.collect(config))

        results = await asyncio.gather(*tasks, return_exceptions=True)
        for r in results:
            if isinstance(r, Exception):
                logger.error(f"采集异常: {r}")
            else:
                all_raw.extend(r)

        logger.info(f"原始数据采集完成: {len(all_raw)} 条")

        # 数据清洗
        cleaned: List[CleanedDataItem] = []
        if auto_clean and all_raw:
            cleaned = self.cleaner.clean_batch(all_raw)

        # 关闭连接
        for c in self.collectors.values():
            await c.close()

        return all_raw, cleaned

    async def collect_and_store(
        self,
        keywords: List[str],
        sources: Optional[List[DataSource]] = None,
        max_items: int = 1000,
    ) -> List[CleanedDataItem]:
        """快捷方法: 采集 + 清洗 + 返回结果"""
        config = CollectionConfig(
            sources=sources or [DataSource.INDUSTRY, DataSource.MARKET, DataSource.USER_BEHAVIOR],
            keywords=keywords,
            max_items=max_items,
        )
        _, cleaned = await self.run_collection(config)
        return cleaned
