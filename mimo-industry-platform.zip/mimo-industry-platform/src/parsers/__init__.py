"""海量数据批量解析引擎

接入 MiMo 百万级超长上下文能力，完成:
- 海量历史数据汇总复盘
- 数据逻辑梳理
- 维度拆分整合
"""

import asyncio
import json
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from loguru import logger

from ..utils.config import get_setting
from ..utils.mimo_engine import get_engine
from ..utils.models import (
    CleanedDataItem, ParseResult, DataChunk, AggregatedData,
)


class DataParser:
    """数据解析器 - 基于 MiMo 的智能解析引擎"""

    def __init__(self):
        self.engine = get_engine()
        self.chunk_size = get_setting("parser.chunk_size", 50000)
        self.overlap_size = get_setting("parser.overlap_size", 2000)
        self.batch_size = get_setting("parser.batch_size", 50)

    # ----------------------------------------------------------------
    # 核心解析流程
    # ----------------------------------------------------------------

    async def parse_batch(
        self,
        items: List[CleanedDataItem],
        industry: str = "",
        analysis_focus: Optional[List[str]] = None,
    ) -> ParseResult:
        """批量解析数据，提取结构化信息

        流程:
        1. 将数据按维度聚合
        2. 调用 MiMo 进行逻辑梳理
        3. 提取关键维度和发现
        """
        batch_id = str(uuid.uuid4())[:8]
        start_time = datetime.now()
        logger.info(f"开始批量解析 | batch={batch_id} | items={len(items)}")

        # Step 1: 数据分组
        grouped = self._group_by_dimensions(items)
        logger.info(f"数据分组完成: {len(grouped)} 个维度组合")

        # Step 2: 构建解析任务
        all_findings: List[str] = []
        all_dimensions: Dict[str, set] = {}
        parsed_count = 0
        failed_count = 0

        for group_key, group_items in grouped.items():
            try:
                # 将同组数据合并为文本块
                content_blocks = self._build_content_blocks(group_items)

                # 调用 MiMo 解析
                for block in content_blocks:
                    findings = await self._analyze_block(block, industry, analysis_focus)
                    all_findings.extend(findings.get("key_findings", []))

                    # 提取维度
                    for dim, values in findings.get("dimensions", {}).items():
                        if dim not in all_dimensions:
                            all_dimensions[dim] = set()
                        all_dimensions[dim].update(values)

                    parsed_count += 1

            except Exception as e:
                logger.error(f"解析失败: {group_key} - {e}")
                failed_count += 1

        # Step 3: 计算数据质量
        quality_scores = [item.quality_score for item in items if item.quality_score > 0]
        avg_quality = sum(quality_scores) / len(quality_scores) if quality_scores else 0.0

        elapsed = (datetime.now() - start_time).total_seconds()
        result = ParseResult(
            batch_id=batch_id,
            total_items=len(items),
            parsed_items=parsed_count,
            failed_items=failed_count,
            dimensions_extracted={k: list(v) for k, v in all_dimensions.items()},
            key_findings=list(set(all_findings)),
            data_quality=round(avg_quality, 2),
            execution_time_seconds=round(elapsed, 1),
        )
        logger.info(f"批量解析完成 | {parsed_count}/{len(items)} | 耗时 {elapsed:.1f}s")
        return result

    async def parse_long_context(
        self,
        items: List[CleanedDataItem],
        industry: str,
        question: str = "",
    ) -> str:
        """利用 MiMo 超长上下文能力处理海量数据

        将所有数据拼接为长文本，通过阶梯式处理进行深度分析
        """
        logger.info(f"超长上下文解析 | 数据量: {len(items)} 条 | 行业: {industry}")

        # 拼接所有数据内容
        all_content = []
        for item in items:
            block = f"## {item.title}\n来源: {item.source.value} | 分类: {item.category}\n{item.content}"
            all_content.append(block)

        combined = "\n\n---\n\n".join(all_content)
        logger.info(f"拼接完成: {len(combined)} 字符")

        system_prompt = f"""你是一个专业的{industry}行业数据分析专家。
请对以下海量行业数据进行深度分析和逻辑梳理。

分析要求:
1. 梳理数据之间的逻辑关系和趋势
2. 按维度拆分整合数据 (时间、地域、品类等)
3. 提取关键的市场信号和异常点
4. 识别数据中的矛盾或不一致之处
5. 给出数据驱动的核心结论

请用结构化的方式输出分析结果。"""

        question_text = f"\n\n具体分析重点: {question}" if question else ""

        result = await self.engine.long_context_infer(
            system_prompt=system_prompt,
            long_content=combined + question_text,
            chunk_size=self.chunk_size,
            overlap=self.overlap_size,
            summary_prompt="请提取此数据块的核心信息点、关键数据指标、趋势信号，用要点列表输出。",
        )

        return result

    # ----------------------------------------------------------------
    # 数据聚合
    # ----------------------------------------------------------------

    async def aggregate_data(
        self,
        items: List[CleanedDataItem],
        industry: str,
        time_range: str = "",
    ) -> AggregatedData:
        """将清洗后的数据聚合成行业维度的汇总数据"""
        logger.info(f"数据聚合 | {len(items)} 条 | 行业: {industry}")

        # 按分类统计
        category_counts: Dict[str, int] = {}
        source_counts: Dict[str, int] = {}
        dimension_data: Dict[str, Any] = {}
        all_metrics: Dict[str, float] = {}

        for item in items:
            category_counts[item.category] = category_counts.get(item.category, 0) + 1
            source_counts[item.source.value] = source_counts.get(item.source.value, 0) + 1

            for dim, val in item.dimensions.items():
                if dim not in dimension_data:
                    dimension_data[dim] = {}
                dimension_data[dim][val] = dimension_data[dim].get(val, 0) + 1

        # 尝试从 JSON 数据中提取数值指标
        for item in items:
            if item.source.value in ("market", "user_behavior"):
                try:
                    data = json.loads(item.content)
                    metrics = data.get("metrics", data.get("search_trends", {}))
                    for k, v in metrics.items():
                        if isinstance(v, (int, float)):
                            if k not in all_metrics:
                                all_metrics[k] = []
                            all_metrics[k].append(v)
                except (json.JSONDecodeError, AttributeError):
                    pass

        # 计算均值
        avg_metrics = {}
        for k, v in all_metrics.items():
            if isinstance(v, list) and v:
                avg_metrics[f"avg_{k}"] = round(sum(v) / len(v), 2)

        # 用 MiMo 生成聚合摘要
        summary_prompt = f"基于 {len(items)} 条{industry}行业数据的分类统计和指标，请给出数据概览总结。"
        summary_data = f"分类分布: {category_counts}\n来源分布: {source_counts}\n指标均值: {avg_metrics}"
        summary_result = await self.engine.chat([
            {"role": "system", "content": f"你是{industry}行业数据分析专家，请简明扼要地总结数据概览。"},
            {"role": "user", "content": f"{summary_prompt}\n\n{summary_data}"},
        ])

        return AggregatedData(
            aggregation_id=str(uuid.uuid4())[:8],
            industry=industry,
            time_range=time_range,
            dimensions={
                "categories": category_counts,
                "sources": source_counts,
                "dimension_breakdown": dimension_data,
            },
            metrics=avg_metrics,
            summary=summary_result["content"],
            source_count=len(items),
        )

    # ----------------------------------------------------------------
    # 内部方法
    # ----------------------------------------------------------------

    def _group_by_dimensions(self, items: List[CleanedDataItem]) -> Dict[str, List[CleanedDataItem]]:
        """按维度分组数据"""
        groups: Dict[str, List[CleanedDataItem]] = {}
        for item in items:
            key = f"{item.category}|{item.source.value}"
            if key not in groups:
                groups[key] = []
            groups[key].append(item)
        return groups

    def _build_content_blocks(self, items: List[CleanedDataItem]) -> List[str]:
        """将数据条目构建为内容块"""
        blocks = []
        current_block = ""
        current_len = 0

        for item in items:
            entry = f"### {item.title}\n分类: {item.category}\n{item.content}\n\n"
            if current_len + len(entry) > self.chunk_size:
                if current_block:
                    blocks.append(current_block)
                current_block = entry
                current_len = len(entry)
            else:
                current_block += entry
                current_len += len(entry)

        if current_block:
            blocks.append(current_block)

        return blocks or [""]

    async def _analyze_block(
        self,
        content: str,
        industry: str,
        focus: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """调用 MiMo 分析单个数据块"""
        focus_text = ""
        if focus:
            focus_text = f"\n重点分析维度: {', '.join(focus)}"

        messages = [
            {
                "role": "system",
                "content": f"""你是一个{industry}行业数据分析引擎。
请从以下数据中提取结构化信息。

输出 JSON 格式:
{{
  "key_findings": ["发现1", "发现2", ...],
  "dimensions": {{
    "time_periods": [...],
    "regions": [...],
    "categories": [...],
    "metrics": [...]
  }},
  "data_quality_notes": "数据质量说明"
}}""",
            },
            {
                "role": "user",
                "content": f"请分析以下数据:{focus_text}\n\n{content[:self.chunk_size]}",
            },
        ]

        result = await self.engine.chat(messages, json_mode=True)

        try:
            return json.loads(result["content"])
        except json.JSONDecodeError:
            return {"key_findings": [result["content"][:500]], "dimensions": {}}
